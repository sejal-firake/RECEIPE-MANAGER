from django.shortcuts import render ,redirect

from django.http import HttpResponse
from .utils import send_email_to_client

def send_email(request):
    send_email_to_client()
    return  redirect('/')

def home(request):
    peoples = [

        {"name" : "Riya", "age" : 12},
        {"name" : "Siya", "age" : 17},
        {"name" : "Ram", "age" : 25},
        {"name" : "Rajat", "age" : 21},
        {"name" : "Rina", "age" : 18},
        {"name" : "Ramesh", "age" : 42},

    ]




    return render(request,'home/index.html' , context = {'peoples' : peoples})

    
def about(request):
    return render(request,'home/about.html')

def contact(request):
    return render(request,'home/contact.html')